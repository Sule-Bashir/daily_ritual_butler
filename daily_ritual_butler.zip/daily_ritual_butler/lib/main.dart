import 'package:flutter/material.dart';

void main() {
  runApp(const DailyButlerApp());
}

class DailyButlerApp extends StatelessWidget {
  const DailyButlerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Daily Ritual Butler',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Sample list of daily rituals
  List<Ritual> rituals = [
    Ritual(id: 1, title: 'Morning Meditation', duration: 10, completed: false),
    Ritual(id: 2, title: 'Drink 500ml Water', duration: 2, completed: true),
    Ritual(id: 3, title: 'Plan Your Day', duration: 5, completed: false),
    Ritual(id: 4, title: 'Evening Journal', duration: 15, completed: false),
    Ritual(id: 5, title: 'Digital Detox', duration: 30, completed: false),
  ];

  int get completedCount => rituals.where((r) => r.completed).length;
  double get progress => rituals.isNotEmpty ? completedCount / rituals.length : 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Daily Ritual Butler 🎯'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              setState(() {
                // Reset all to incomplete
                for (var ritual in rituals) {
                  ritual.completed = false;
                }
              });
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Progress Card
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.blue.shade50,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Today\'s Progress',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),
                    Chip(
                      label: Text('$completedCount/${rituals.length}'),
                      backgroundColor: Colors.blue.shade100,
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                LinearProgressIndicator(
                  value: progress,
                  backgroundColor: Colors.grey.shade300,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    progress >= 1 ? Colors.green : Colors.blue,
                  ),
                  minHeight: 10,
                ),
                const SizedBox(height: 8),
                Text(
                  '${(progress * 100).toStringAsFixed(0)}% Complete',
                  style: TextStyle(
                    color: Colors.grey.shade700,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),

          // Motivation Card
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.orange.shade50, Colors.yellow.shade50],
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Row(
              children: [
                Icon(Icons.lightbulb_outline, color: Colors.amber, size: 24),
                SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Daily Motivation',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Consistency is the key to mastery. Your small daily rituals create extraordinary results.',
                        style: TextStyle(fontSize: 14),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Text(
                  'Your Rituals',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ],
            ),
          ),

          // Rituals List - FIXED WITH EXPANDED WIDGET
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: rituals.length,
              itemBuilder: (context, index) {
                final ritual = rituals[index];
                return _buildRitualCard(ritual);
              },
            ),
          ),

          // Mood Tracker
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.grey.shade100,
            child: Column(
              children: [
                const Text(
                  'How do you feel after your rituals?',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(5, (index) {
                    return IconButton(
                      icon: Icon(
                        Icons.sentiment_very_satisfied,
                        color: index < 3 ? Colors.amber : Colors.grey,
                        size: 30,
                      ),
                      onPressed: () {
                        _showSnackbar('Mood recorded: ${index + 1}/5');
                      },
                    );
                  }),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addNewRitual,
        child: const Icon(Icons.add),
        backgroundColor: Colors.blue,
      ),
    );
  }

  Widget _buildRitualCard(Ritual ritual) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: ListTile(
        leading: Checkbox(
          value: ritual.completed,
          onChanged: (value) {
            _toggleRitual(ritual.id);
          },
          shape: const CircleBorder(),
        ),
        title: Text(
          ritual.title,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            decoration: ritual.completed
                ? TextDecoration.lineThrough
                : TextDecoration.none,
          ),
        ),
        subtitle: Text('${ritual.duration} minutes'),
        trailing: Chip(
          label: Text(ritual.completed ? 'Done' : 'Pending'),
          backgroundColor: ritual.completed
              ? Colors.green.shade100
              : Colors.orange.shade100,
        ),
        onTap: () {
          _toggleRitual(ritual.id);
        },
      ),
    );
  }

  void _toggleRitual(int id) {
    setState(() {
      for (var ritual in rituals) {
        if (ritual.id == id) {
          ritual.completed = !ritual.completed;
          break;
        }
      }
    });

    // Show celebration when all complete
    if (completedCount == rituals.length) {
      _showSnackbar('🎉 Amazing! All rituals completed for today!');
    }
  }

  void _addNewRitual() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add New Ritual'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              decoration: const InputDecoration(
                labelText: 'Ritual Name',
                hintText: 'e.g., Evening Stretch',
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              decoration: const InputDecoration(
                labelText: 'Duration (minutes)',
              ),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              setState(() {
                final newId = rituals.isNotEmpty ? rituals.last.id + 1 : 1;
                rituals.add(Ritual(
                  id: newId,
                  title: 'New Ritual',
                  duration: 10,
                  completed: false,
                ));
              });
              Navigator.pop(context);
              _showSnackbar('New ritual added!');
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  void _showSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}

class Ritual {
  final int id;
  final String title;
  final int duration;
  bool completed;

  Ritual({
    required this.id,
    required this.title,
    required this.duration,
    required this.completed,
  });
}